/**
 * Seed script for UPLINK 1 - Ideas only
 * Adds comprehensive demo data for testing the platform
 */

import mysql from 'mysql2/promise';

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL not found in environment');
  process.exit(1);
}

async function seedIdeas() {
  console.log('🌱 Starting UPLINK 1 seed process...');
  
  const connection = await mysql.createConnection(DATABASE_URL);
  
  try {
    // Check existing ideas count
    const [rows] = await connection.query('SELECT COUNT(*) as count FROM ideas');
    const existingCount = rows[0].count;
    
    if (existingCount > 0) {
      console.log(`\n⚠️  Found ${existingCount} existing ideas. Clearing table...`);
      await connection.query('DELETE FROM ideas');
      console.log('✅ Table cleared');
    }
    
    console.log('\n📝 Seeding UPLINK 1 - Ideas...');
    
    const ideasSQL = `
      INSERT INTO ideas (userId, title, description, category, status)
      VALUES
        -- High-scoring approved ideas (Innovation)
        (1, 'نظام ذكاء اصطناعي لإدارة الطاقة المتجددة', 'منصة متقدمة تستخدم الذكاء الاصطناعي والتعلم الآلي لتحسين استهلاك الطاقة الشمسية في المباني السكنية والتجارية من خلال التنبؤ بأنماط الاستهلاك وتحسين التخزين والتوزيع', 'تقنية', 'approved'),
        (1, 'تطبيق ذكي للتشخيص الطبي المبكر', 'تطبيق طبي يستخدم الذكاء الاصطناعي وتحليل الصور الطبية والبيانات الحيوية للكشف المبكر عن الأمراض المزمنة مثل السكري وأمراض القلب والسرطان', 'صحة', 'approved'),
        (1, 'تقنية تحلية المياه بالطاقة الشمسية', 'نظام تحلية مياه مبتكر يعمل بالطاقة الشمسية بتكلفة منخفضة ومناسب للمناطق النائية والصحراوية مع تقنية تنقية متقدمة', 'بيئة', 'approved'),
        (1, 'نظام أمن سيبراني متقدم للشركات الصغيرة', 'حل أمني متكامل يحمي الشركات الصغيرة والمتوسطة من الهجمات السيبرانية باستخدام الذكاء الاصطناعي والتعلم الآلي لاكتشاف التهديدات', 'أمن سيبراني', 'approved'),
        (1, 'نظام إدارة المخزون الذكي', 'نظام متطور يستخدم IoT والذكاء الاصطناعي لإدارة المخزون تلقائياً في المستودعات والمتاجر مع تنبؤ بالطلب وتحسين سلسلة التوريد', 'تقنية', 'approved'),
        
        -- Medium-scoring ideas
        (1, 'منصة تعليمية تفاعلية للأطفال', 'منصة تعليمية مبتكرة تستخدم الألعاب والواقع المعزز لتعليم الأطفال المهارات الأساسية بطريقة ممتعة وتفاعلية مع محتوى عربي أصيل', 'تعليم', 'approved'),
        (1, 'روبوت خدمة عملاء ذكي', 'روبوت محادثة متطور يستخدم معالجة اللغة الطبيعية لتقديم خدمة عملاء احترافية بالعربية على مدار الساعة مع فهم سياق المحادثة', 'تقنية', 'approved'),
        (1, 'منصة تمويل جماعي للمشاريع الإبداعية', 'منصة رقمية تربط المبدعين والفنانين بالممولين لتمويل المشاريع الإبداعية والفنية في المنطقة العربية', 'مالية', 'approved'),
        
        -- Ideas under analysis
        (1, 'تطبيق توصيل طعام صحي', 'تطبيق يربط المطاعم الصحية بالعملاء مع نظام توصيات غذائية مخصصة بناءً على الحالة الصحية والأهداف الغذائية', 'خدمات', 'analyzing'),
        (1, 'منصة حجز مواقف السيارات الذكية', 'تطبيق يساعد السائقين في إيجاد وحجز مواقف السيارات في المدن الكبرى باستخدام خرائط تفاعلية وحجز مسبق', 'خدمات', 'analyzing'),
        
        -- Draft ideas
        (1, 'نظام إدارة المشاريع السحابي', 'منصة سحابية متكاملة لإدارة المشاريع والفرق مع أدوات تعاون وتتبع المهام وإدارة الموارد', 'تقنية', 'draft'),
        (1, 'تطبيق تعلم اللغات بالذكاء الاصطناعي', 'تطبيق تفاعلي لتعلم اللغات يستخدم الذكاء الاصطناعي لتخصيص المحتوى حسب مستوى المتعلم وأسلوب التعلم', 'تعليم', 'draft'),
        (1, 'منصة تجارة إلكترونية للمنتجات المحلية', 'سوق إلكتروني يربط المنتجين المحليين بالمستهلكين مباشرة لدعم الاقتصاد المحلي والمنتجات الوطنية', 'تجارة', 'draft'),
        
        -- Recently submitted
        (1, 'نظام مراقبة جودة الهواء الذكي', 'شبكة من أجهزة الاستشعار الذكية لمراقبة جودة الهواء في المدن وتقديم تنبيهات وتوصيات للمواطنين', 'بيئة', 'submitted'),
        (1, 'تطبيق إدارة الصحة الشخصية', 'تطبيق شامل لتتبع الصحة الشخصية يشمل النشاط البدني والتغذية والنوم مع توصيات مخصصة', 'صحة', 'submitted')
    `;
    
    await connection.query(ideasSQL);
    console.log('✅ Inserted 15 ideas with various statuses');
    
    // Show summary by status
    const [summary] = await connection.query(`
      SELECT status, COUNT(*) as count 
      FROM ideas 
      GROUP BY status
      ORDER BY count DESC
    `);
    
    console.log('\n📊 Ideas Summary by Status:');
    summary.forEach(row => {
      console.log(`   - ${row.status}: ${row.count} ideas`);
    });
    
    console.log('\n✅ UPLINK 1 seed completed successfully!');
    console.log('🎉 Platform now has comprehensive demo data for testing');
    
  } catch (error) {
    console.error('❌ Error seeding data:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

seedIdeas()
  .then(() => {
    console.log('\n✅ Seeding process finished successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Seeding process failed:', error);
    process.exit(1);
  });
